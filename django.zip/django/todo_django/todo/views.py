from django.shortcuts import render
from todo.models import Todo
from django.views import View
from django.template.response import TemplateResponse
from django.http import HttpResponse, HttpResponseRedirect


# Create your views here.
class TodoListView(View):
    def get(self, request):
        context ={
            'todo_list':Todo.objects.all()
        }
        return TemplateResponse(request, 'todo_list.html', context)
class TodoAddView(View):
    def get(self, request):
        return TemplateResponse(request, 'todo_add_list.html', {})
    def post(self, request):
        description = request.POST['description']
        fecha = request.POST['fecha']
        unidades = request.POST['unidades']
        Todo.objects.create(description=description,fecha=fecha,unidades=unidades)
        return HttpResponseRedirect('/')
        
